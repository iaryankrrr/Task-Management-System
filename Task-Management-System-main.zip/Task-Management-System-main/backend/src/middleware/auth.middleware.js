const jwt = require('jsonwebtoken');
const asyncHandler = require('express-async-handler');
const { supabase } = require('../config/db');

const protect = asyncHandler(async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      const { data: user, error } = await supabase
        .from('users')
        .select('id, name, email, role, avatar, is_active')
        .eq('id', decoded.id)
        .single();

      if (error || !user) {
        res.status(401);
        throw new Error('User not found');
      }
      
      req.user = {
        _id: user.id,
        ...user
      };

      next();
    } catch (error) {
      res.status(401);
      throw new Error('Not authorized, token failed');
    }
  }

  if (!token) {
    res.status(401);
    throw new Error('Not authorized, no token');
  }
});

const adminOnly = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403);
    throw new Error('Access denied: Admins only');
  }
};

module.exports = { protect, adminOnly };

